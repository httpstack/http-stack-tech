<?php

namespace App;

class Router {
    private array $routes = [];
    private $container;

    public function __construct($container = null) {
        $this->container = $container;
    }

    public function addRoute(string $method, string $path, $handler): void {
        $this->routes[] = [
            'method' => strtoupper($method),
            'path' => $this->parsePath($path),
            'handler' => $handler,
        ];
    }

    public function get(string $path, $handler): void {
        $this->addRoute('GET', $path, $handler);
    }

    private function parsePath(string $path): string {
        // Convert placeholders like /user/{id} to regex /user/([^/]+)
        return preg_replace('/\{([^}]+)\}/', '([^/]+)', $path);
    }

    public function dispatch(string $method, string $uri, $request, $response): void {
        $uri = rtrim($uri, '/'); // Normalize URI
        foreach ($this->routes as $route) {
            if ($method === $route['method'] && preg_match('#^' . $route['path'] . '$#', $uri, $matches)) {
                array_shift($matches); // Remove the full match

                // Resolve the handler
                $handler = $route['handler'];

                // If the handler is a class method, resolve it from the container
                if (is_array($handler) && is_string($handler[0]) && $this->container) {
                    $handler[0] = $this->container->resolve($handler[0]);
                }

                // Add URL parameters to the Request object
                $request->setParams($matches);

                // Call the handler with Request, Response, and Container
                call_user_func($handler, $request, $response, ...$matches);
                return;
            }
        }

        // If no route matches, return a 404 response
        $response->setStatusCode(404);
        $response->setBody('<h1>404 Not Found</h1>');
        $response->send();
    }
}