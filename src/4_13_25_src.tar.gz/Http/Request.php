<?php

namespace Cmcintosh\Httpstack\Http;

class Request implements RequestInterface {
    private string $method;
    private string $uri;
    private array $queryParams;
    private string $body;
    private array $headers;

    public function __construct() {
        $this->method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
        $this->uri = $_SERVER['REQUEST_URI'] ?? '/';
        $this->queryParams = $_GET;
        $this->body = file_get_contents('php://input');
        $this->headers = getallheaders();
    }

    public function getMethod(): string {
        return $this->method;
    }

    public function getUri(): string {
        return $this->uri;
    }

    public function getQueryParams(): array {
        return $this->queryParams;
    }

    public function getBody(): string {
        return $this->body;
    }

    public function getHeaders(): array {
        return $this->headers;
    }

    public function getHeader(string $name): ?string {
        return $this->headers[$name] ?? null;
    }
}

?>