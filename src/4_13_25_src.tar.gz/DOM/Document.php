<?php
namespace Cmcintosh\Httpstack\DOM;

use DOMDocument;
use DOMNode;

class Document extends DOMDocument{


}


?>